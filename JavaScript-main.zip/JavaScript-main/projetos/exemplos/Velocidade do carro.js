var vel = 50.5
console.log(`A velocidade do seu carro é ${vel}km/h`)
if (vel > 60) {
    console.log('VOCÈ FOI MULTADO!')
}
console.log('Dirija sempre usando cinto de segurança')