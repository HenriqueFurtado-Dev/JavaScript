var país = 'frança'
console.log (`Você nasceu em: ${país}`)
if (país == 'Brasil') {
    console.log('Você é brasileiro')
}
else {
    console.log('Você é gringo! ')
}