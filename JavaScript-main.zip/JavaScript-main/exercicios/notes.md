#Anotações

" ou ' = podem ser utilizadas

(number) + (number) = soma
(string) + (string) = concatenação


##tipos primitivos

Number
String
Boolean
Null == CAMPO VAZIO


###Definindo tipos primitivos numbers
<script>
    var n1 = Number.parseInt(window.prompt("Digite um teste:")) //inteiro
    var n2 = Number.parseFloat(window.prompt("Digite outro teste:")) //flutuante
</script>

###PlaceHolder 
${teste} = utilizado com `crase`